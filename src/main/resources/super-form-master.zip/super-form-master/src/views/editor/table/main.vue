<template lang="pug">
  el-main table-main
</template>

<script>
export default {};
</script>
