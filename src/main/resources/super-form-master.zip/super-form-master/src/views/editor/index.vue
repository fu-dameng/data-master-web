<template lang="pug">
  el-container
    router-view(name="aside" style="width:380px")
    router-view(name="main")
</template>

<script>
export default {};
</script>
